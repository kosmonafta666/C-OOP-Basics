﻿namespace Defining_Classes_Lab
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            BankAccount acount = new BankAccount();

            acount.ID = 1;

            acount.Balance = 15;

            Console.WriteLine($"Account{acount.ID}, balance{ acount.Balance}");
        }
    }
}
