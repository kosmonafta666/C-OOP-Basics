﻿using System;


public abstract class Harvester
{
    private string id;
    private float oreOutput;
    private double energyRequirement;

    public string Id
    {
        get { return this.id; }
        protected set
        {
            this.id = value;
        }
    }

    public float OreOutput
    {
        get { return this.oreOutput; }
        protected set
        {
            this.oreOutput = value;
        }
    }

    public double EnergyRequirement
    {
        get { return this.energyRequirement; }
        protected set
        {
            this.energyRequirement = value;
        }
    }

    protected Harvester(string id, float oreOutput, double energyRequirement)
    {
        this.Id = id;
        this.OreOutput = oreOutput;
        this.EnergyRequirement = energyRequirement;
    }
}

