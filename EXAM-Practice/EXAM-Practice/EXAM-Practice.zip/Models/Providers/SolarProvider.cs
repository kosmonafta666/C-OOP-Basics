﻿using System;

class SolarProvider : Provider
{
    public SolarProvider(string id, double energyOutput)
        :base (id, energyOutput)
    {
    }
}

