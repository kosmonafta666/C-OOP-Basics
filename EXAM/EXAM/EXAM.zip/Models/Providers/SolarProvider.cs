﻿using System;

public class SolarProvider : Provider
{
    public SolarProvider(string id, float energyOutput)
        :base(id, energyOutput)
    {
    }
}

