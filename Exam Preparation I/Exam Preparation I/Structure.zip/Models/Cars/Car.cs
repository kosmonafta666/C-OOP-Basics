﻿using System;
using System.Text;

public abstract class Car
{
    private string brand;
    private string model;
    private int yearOfProduction;
    private int horsePower;
    private int acceleration;
    private int suspension;
    private int durability;

    protected string Brand
    {
        get { return this.brand; }
        set
        {
            this.brand = value;
        }
    }

    protected string Model
    {
        get { return this.model; }
        set
        {
            this.model = value;
        }
    }

    protected int YearOfProduction
    {
        get { return this.yearOfProduction; }
        set
        {
            this.yearOfProduction = value;
        }
    }

    protected int HorsePower
    {
        get { return this.horsePower; }
        set
        {
            this.horsePower = value;
        }
    }

    protected int Acceleration
    {
        get { return this.acceleration; }
        set
        {
            this.acceleration = value;
        }
    }

    protected int Suspension
    {
        get { return this.suspension; }
        set
        {
            this.suspension = value;
        }
    }

    protected int Durability
    {
        get { return this.durability; }
        set
        {
            this.durability = value;
        }
    }

    public Car(string brand, string model, int yearOfProduction, 
        int horsePower, int acceleration, int suspension, int durabilty)
    {
        this.Brand = brand;
        this.Model = model;
        this.YearOfProduction = yearOfProduction;
        this.HorsePower = horsePower;
        this.Acceleration = acceleration;
        this.Suspension = suspension;
        this.Durability = durabilty;
    }

    public override string ToString()
    {
        var result = new StringBuilder();

        result.AppendLine($"{this.Brand} {this.Model} {this.YearOfProduction}");
        result.AppendLine($"{this.HorsePower} HP, 100 m/h in {this.Acceleration} s");
        result.AppendLine($"{this.Suspension} Suspension force, {this.Durability} Durability");

        return result.ToString();
    }
}

